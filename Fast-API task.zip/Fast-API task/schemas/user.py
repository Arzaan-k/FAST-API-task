from bson import ObjectId
# Normal way
def userEntity(item) -> dict:
    return {
        "id":str(item["_id"]),
        "name":item["name"],
        "email":item["email"],
        "password":item["password"]
    }

def usersEntity(entity) -> list:
    return [userEntity(item) for item in entity]
#Best way

# def serializeDict(a) -> dict:
#     return {**{i:str(a[i]) for i in a if i=='_id'},**{i:a[i] for i in a if i!='_id'}}

# def serializeList(entity) -> list:
#     return [serializeDict(a) for a in entity]

def serializeDict(a) -> dict:
    if a is None:
        return None
    return {str(i): str(a[i]) if not isinstance(a[i], ObjectId) else str(a[i]) for i in a}

def serializeList(entity) -> list:
    return [serializeDict(a) for a in entity]